-- leaked by axom | our discord server : https://discord.gg/Sps39CydcZ | Our YouTube channel : https://youtube.com/@axos0022

This is the data of OmniDBF (OmniDBF dumper data.txt is the data containing the HWID, Display name, username, executer, etc)
and the roblox sandboxed env is the file "roblox" which has all standard roblox services (located in /app/envlogger/src/env/roblox/

note : they added better anti env detection that also detects tampering inputs but it have been bypassed, (again). 