-- leaked by axom | our discord server : https://discord.gg/Sps39CydcZ | Our YouTube channel : https://youtube.com/@axos0022

local env = getfenv()
local fake = "IMAXOM333444555666888"
env.gethwid = function() return fake end
local hwid = env.gethwid()
error("HWID changed to: " .. hwid)

-- this hijacks the HWID to believe this custom fake hwid is the real hwid, run it yourself to see before it'scpatched