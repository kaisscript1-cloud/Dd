_________________
# LEAKED BY AXOM |_______ https://discord.gg/axomx |____ https://discord.gg/Sps39CydcZ |  https://youtube.com/@axos0022 | 
axomicpcr                     | 
-------------------------------

there was more to leak (like luaurenamer.py, /mods directory which has utilities like luaparse, etc) but his .l suddenly crashed with error "❌ error: spawn lune failed: spawn lune ENOENT"

and .moonsecdeobf returns "error: read ECONNRESET"


but yeah, bot uses public sources. why put protection?. 
no personal issue, axomicpcr fights pasted code


How were the Bot leaked? 
at first, print(readfile("something")) would work, but then the owner added checking of outputs, when it sees pattern of token or src leak, it says "Output empty"
so, i made it just encode the output in base64 and use the operation before he later probably patched readfile operation completely. 

