const { Client, GatewayIntentBits, MessageAttachment } = require('discord.js');
const fs = require('fs');
const path = require('path');

// Bot configuration
const TOKEN = 'MTUyMzYzMDkxNzk2MzQ4MTI0OA.GhsQkE.GpDA282MrDNH3lo-9I0O22tQRcmvtvHgVHdIFw';
const PREFIX = '!';

// Create client with all necessary intents
const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMessageReactions
    ]
});

// Helper function to generate random ID
function generateId(length) {
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
        result += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    return result;
}

// Helper function to create attachment
async function createAttachment(content, filename) {
    return new MessageAttachment(
        Buffer.from(content, 'utf-8'),
        filename
    );
}

// Function to rename code with retry mechanism
async function renameCodeWithRetry(code, maxRetries = 3) {
    const API_URL = 'https://renamer-api.vercel.app/api/rename';
    const API_KEY = '7f1c-CHKLH-97928';
    
    let lastError = null;
    
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
        try {
            console.log(`Attempt ${attempt}/${maxRetries} to rename code...`);
            
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), 15000); // 15 second timeout
            
            const response = await fetch(API_URL, {
                method: 'POST',
                headers: {
                    'x-api-key': API_KEY,
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                },
                body: JSON.stringify({ code: code }),
                signal: controller.signal,
            });
            
            clearTimeout(timeoutId);
            
            if (!response.ok) {
                const errorText = await response.text();
                throw new Error(`API returned ${response.status}: ${errorText}`);
            }
            
            const data = await response.json();
            
            if (!data.renamedCode) {
                throw new Error('No renamed code in response');
            }
            
            return data;
            
        } catch (error) {
            lastError = error;
            console.error(`Attempt ${attempt} failed:`, error.message);
            
            // Don't wait on last attempt
            if (attempt < maxRetries) {
                const waitTime = attempt * 2000; // Progressive backoff
                console.log(`Waiting ${waitTime}ms before retry...`);
                await new Promise(resolve => setTimeout(resolve, waitTime));
            }
        }
    }
    
    throw new Error(`All ${maxRetries} attempts failed: ${lastError?.message || 'Unknown error'}`);
}

client.once('ready', () => {
    console.log(`✅ Bot is online as ${client.user.tag}`);
    console.log(`📝 Prefix: ${PREFIX}`);
    console.log(`🌐 API: https://renamer-api.vercel.app/api/rename`);
});

client.on('messageCreate', async (message) => {
    // Ignore bot messages
    if (message.author.bot) return;
    if (!message.content.startsWith(PREFIX)) return;

    const args = message.content.slice(PREFIX.length).trim().split(/ +/);
    const command = args.shift().toLowerCase();

    // Command: rename
    if (command === 'rename') {
        let content = message.content.slice(PREFIX.length + command.length).trim();
        
        // Check for code block first
        const codeBlockRegex = /```(?:\w+)?\n([\s\S]*?)```/;
        const match = message.content.match(codeBlockRegex);
        if (match) {
            content = match[1];
        }
        
        // If no code in command, check attachments
        if (!content && message.attachments.size > 0) {
            const attachment = message.attachments.first();
            if (attachment && (attachment.name.endsWith('.lua') || attachment.name.endsWith('.txt'))) {
                try {
                    const response = await fetch(attachment.url);
                    content = await response.text();
                } catch (err) {
                    return message.reply('❌ Failed to read attachment.');
                }
            }
        }

        if (!content || content.length === 0) {
            return message.reply('❌ Please provide Lua code to rename. Usage: `!rename <your lua code>`');
        }

        // Show processing status
        const statusMsg = await message.reply('⏳ Renaming code... (this may take a few seconds)');

        try {
            const start = Date.now();
            
            // Use retry mechanism
            const data = await renameCodeWithRetry(content);
            
            // Delete status message
            await statusMsg.delete();

            // Send renamed code
            await message.reply({
                content: `✅ Renamed code in ${Date.now() - start}ms.`,
                files: [
                    await createAttachment(
                        data.renamedCode,
                        generateId(16) + '.lua'
                    ),
                ],
            });

        } catch (err) {
            console.error('Error renaming code:', err);
            
            // More specific error messages
            let errorMsg = '❌ Unable to rename code.';
            if (err.message.includes('ConnectTimeout') || err.message.includes('timeout')) {
                errorMsg = '❌ API connection timeout. The service might be down or slow. Please try again later.';
            } else if (err.message.includes('API returned')) {
                errorMsg = `❌ API error: ${err.message}`;
            } else if (err.message.includes('fetch failed')) {
                errorMsg = '❌ Cannot connect to the API. Please check your internet connection.';
            }
            
            await statusMsg.edit(errorMsg);
        }
    }

    // Command: ping - to test connection
    if (command === 'ping') {
        const start = Date.now();
        const msg = await message.reply('Pinging...');
        await msg.edit(`🏓 Pong! Latency: ${Date.now() - start}ms`);
    }

    // Command: status - check API health
    if (command === 'status') {
        const statusMsg = await message.reply('🔍 Checking API status...');
        
        try {
            const start = Date.now();
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), 5000);
            
            const response = await fetch('https://renamer-api.vercel.app/api/rename', {
                method: 'POST',
                headers: {
                    'x-api-key': '7f1c-CHKLH-97928',
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ code: 'print("test")' }),
                signal: controller.signal,
            });
            
            clearTimeout(timeoutId);
            
            if (response.ok) {
                await statusMsg.edit(`✅ API is healthy! Response time: ${Date.now() - start}ms`);
            } else {
                await statusMsg.edit(`⚠️ API responded with status: ${response.status}`);
            }
        } catch (err) {
            await statusMsg.edit(`❌ API is unreachable: ${err.message}`);
        }
    }

    // Command: help
    if (command === 'help') {
        const helpMessage = `
**🤖 Lua Renamer Bot v2.0**

**Commands:**
\`${PREFIX}rename <code>\` - Rename Lua code
\`${PREFIX}rename\` with .lua file attachment - Rename uploaded file
\`${PREFIX}rename\` with code block - Use \`\`\`lua...\`\`\`
\`${PREFIX}ping\` - Check bot latency
\`${PREFIX}status\` - Check API status
\`${PREFIX}help\` - Show this help

**Examples:**
\`${PREFIX}rename function hello() print("world") end\`
\`${PREFIX}rename\` (attach .lua file)
\`\`\`lua
local x = 10
print(x)
\`\`\`

**Troubleshooting:**
- If you get timeout errors, the API might be down
- Use \`${PREFIX}status\` to check API health
- Try again after a few minutes
        `;
        await message.reply(helpMessage);
    }
});

// Error handling
client.on('error', (error) => {
    console.error('Discord client error:', error);
});

// Handle process errors
process.on('unhandledRejection', (error) => {
    console.error('Unhandled promise rejection:', error);
});

// Login
client.login(TOKEN).catch(err => {
    console.error('❌ Failed to login:', err);
});

module.exports = client;